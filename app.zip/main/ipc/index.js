require('./init.js');

require('./command.js');