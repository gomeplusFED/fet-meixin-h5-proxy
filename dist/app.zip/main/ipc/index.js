require('./init.js');

require('./command.js');

require('./pwd-check.js');